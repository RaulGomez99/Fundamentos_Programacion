# -*- coding: utf-8 -*-
"""
Created on Mon Oct 15 13:55:16 2018

@author: Ricardo
"""

def main():
    x = int(input("Dame un entero: "))
    
    if (x < '0'):
        print("El entero es negativo")
    else (x >= '0'):
        print("El entero es positivo")
        
        mes = int(input("Dime el número de un mes: "))
        
        if (mes == 1 == 3 == 5 == 7 == 8 == 10 == 12):
            print("El mes tiene 31 días")
        else if (mes == 4 == 6 == 9 == 11):
            print("El mes tiene 30 días")
        else if (mes == 2):
            print("El mes tiene 28 o 29 días")
        else:
            print("Mes no válido")

        
if __name__ == '__main__':
    main()