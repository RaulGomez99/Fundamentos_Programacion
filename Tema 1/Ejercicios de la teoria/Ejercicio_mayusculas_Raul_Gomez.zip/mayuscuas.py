# -*- coding: utf-8 -*-
"""
Created on Tue Oct  6 12:05:00 2020

Este programa dirá dada una letra si es mayúscula o no lo es

@author: Raul
"""

def main():
    #ENTRADA DE DATOS
    letra = input("Escribe letra");
    
    #PROCESO DE DATOS
    if letra >= "A" and letra <= "Z" or letra == "Ñ":
        print("Es mayúscula");
    else:
        print("No es mayúscula");
    
    
if __name__ == "__main__":
    main()